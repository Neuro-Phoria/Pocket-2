package com.pocketstudios.feature.editor.domain.model

data class VideoClip(
    val id: String,
    val projectId: String,
    val trackIndex: Int,
    val filePath: String,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val timelinePositionMs: Long,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val isMuted: Boolean = false,
    val filterPresetId: String? = null,
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val transitionInId: String? = null,
    val transitionOutId: String? = null,
    val orderIndex: Int = 0
) {
    val durationMs: Long get() = (endTimeMs - startTimeMs)
    val scaledDurationMs: Long get() = (durationMs / speed).toLong()
}

data class AudioTrack(
    val id: String,
    val projectId: String,
    val filePath: String,
    val trackName: String,
    val timelinePositionMs: Long,
    val durationMs: Long,
    val volume: Float = 1.0f,
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    val isLooping: Boolean = false,
    val trackType: AudioTrackType = AudioTrackType.MUSIC
)

enum class AudioTrackType { MUSIC, VOICEOVER, SFX }

data class TextOverlay(
    val id: String,
    val projectId: String,
    val text: String,
    val fontFamily: String = "Inter",
    val fontSize: Float = 32f,
    val textColor: Long = 0xFFFFFFFF,
    val positionX: Float = 0.5f,
    val positionY: Float = 0.8f,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val animationIn: TextAnimation = TextAnimation.FADE_IN,
    val animationOut: TextAnimation = TextAnimation.FADE_OUT,
    val isBold: Boolean = false,
    val isItalic: Boolean = false
)

enum class TextAnimation {
    NONE, FADE_IN, FADE_OUT, SLIDE_UP, SLIDE_DOWN, TYPEWRITER, SCALE_IN
}

data class Project(
    val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val durationMs: Long,
    val thumbnailPath: String?,
    val aspectRatio: AspectRatio,
    val resolution: Resolution,
    val frameRate: Int
)

enum class AspectRatio(val width: Int, val height: Int, val label: String, val ratio: Float) {
    VERTICAL_9_16(9, 16, "9:16 (Reels/TikTok)", 9f / 16f),
    HORIZONTAL_16_9(16, 9, "16:9 (YouTube)", 16f / 9f),
    SQUARE_1_1(1, 1, "1:1 (Instagram)", 1f),
    PORTRAIT_4_5(4, 5, "4:5 (Portrait)", 4f / 5f)
}

enum class Resolution(val width: Int, val height: Int, val label: String, val isPro: Boolean) {
    HD_720(1280, 720, "720p HD", false),
    FHD_1080(1920, 1080, "1080p Full HD", false),
    UHD_4K(3840, 2160, "4K Ultra HD", true)
}
